package dal;

import data.Measurement;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class DAL
{
	private static final String FILE_PATH = "measurements.ser";
	
  public void saveData(ArrayList<Measurement> measurements) throws IOException
  {
    try
    {
      ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH));
      for (int i = 1; i <= measurements.size(); ++i)
      {
        oos.writeObject(measurements.get(i));
      }
    }
    catch (FileNotFoundException ex)
    {
      System.err.println(ex.toString());
    }
  }

  public ArrayList<Measurement> readData() throws IOException, ClassNotFoundException
  {
		ArrayList<Measurement> measurements = new ArrayList<>();
    try
    {
      ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_PATH));
      int amount = ois.readInt();
      for (int i = 1; i <= amount; ++i)
      {
        measurements.add((Measurement)ois.readObject());        
      }
    }
    catch (FileNotFoundException ex)
    {
      System.err.println(ex.toString());   
		}
		return measurements;
  }
}
